update employee set job_id=14 where fname='pedro'and lname='afonso'; 
--select job_id from pubs.dbo.employee where fname='pedro'and lname='afonso';