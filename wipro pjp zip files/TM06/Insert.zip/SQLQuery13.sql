insert employee  values ('R-R12345F','Reshma',' ','Roy',10,150,'0877','03/05/1990');
